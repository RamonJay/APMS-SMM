package com.sprintManagement.web.mvc.serviceimpl;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sprintManagement.web.mvc.entities.MeetingStatus;
import com.sprintManagement.web.mvc.entities.MeetingType;
import com.sprintManagement.web.mvc.entities.Meetings;
import com.sprintManagement.web.mvc.exceptions.MeetingStatusUpdateFailedException;
import com.sprintManagement.web.mvc.repository.MeetingsRepository;
import com.sprintManagement.web.mvc.service.MeetingDao;

import jakarta.persistence.EntityNotFoundException;

@Service
public class MeetingServices implements MeetingDao {

	@Autowired
	private MeetingsRepository meetingRepository;

	@Override
	public Meetings scheduleNewMeeting(Meetings meeting) {
		// TODO Auto-generated method stub
		return meetingRepository.save(meeting);
	}

	@Override
	public Meetings getMeetingById(Long id) {
		// TODO Auto-generated method stub
		Optional<Meetings> opt = meetingRepository.findById(id);
		if (opt.isPresent()) {
			return opt.get();
		} else {
			throw new EntityNotFoundException("Meeting not found with Id " + id);
		}
	}

	@Override
	public Meetings rescheduleMeeting(Meetings meeting, Long id) throws MeetingStatusUpdateFailedException {
		// TODO Auto-generated method stub
		Optional<Meetings> meet = meetingRepository.findById(id);
		if (meet.isEmpty()) {
			throw new EntityNotFoundException("Meeting not found with Id " + id);
		} else {
			Meetings m = meet.get();
			if (m.getStatus() == MeetingStatus.completed) {
				throw new MeetingStatusUpdateFailedException("Completed meeting cannot be updated");
			}
			meeting.setId(id);
			meeting.setUpdatedon(LocalDate.now());
			meetingRepository.save(meeting);
			return meeting;
		}
	}

	@Override
	public List<Meetings> getAllMeetings() {
		// TODO Auto-generated method stub
		return meetingRepository.findAll();
	}

	@Override
	public String addNewMeeting(Meetings meeting) throws Exception {
		switch (meeting.getMeetingtype()) {
		case DailyScrum:
			LocalDate firstDate = meeting.getCreatedon();
			LocalDate endDate = meeting.getSprint().getEnddate();
			long meetingid = meeting.getId();
			while (firstDate.isBefore(endDate)) {
				Meetings dailyMeeting = new Meetings();
				dailyMeeting = meeting;
				dailyMeeting.setId(meetingid++);
				dailyMeeting.setMeetingdate(firstDate);
				meetingRepository.save(dailyMeeting);
				firstDate = firstDate.plusDays(1);
			}
			return "DailyScrum meeting is added from " + meeting.getCreatedon() + " to "
					+ meeting.getSprint().getEnddate();
		case SprintPlanning:
			LocalDate meetingdate = meeting.getSprint().getStartdate();
			meeting.setMeetingdate(meetingdate);
			meetingRepository.save(meeting);
			return "Sprint Planning meeting scheduled successfully on " + meetingdate;
		case SprintReview:
			LocalDate meetingDate = meeting.getSprint().getEnddate();
			meeting.setMeetingdate(meetingDate);
			meetingRepository.save(meeting);
			return "SprintReview meeting is scheduled successfully on " + meetingDate;
		case SprintRetrospective:
			LocalDate meetingDa = meeting.getSprint().getEnddate();
			meeting.setMeetingdate(meetingDa);
			meetingRepository.save(meeting);
			return "SprintRetrospective meeting is scheduled successfully on " + meetingDa;
		default: throw new Exception("Meeting Type should be DailyScrum/SprintPlanning/SprintReview/SprintRetrospective");
		}

	}

}