package com.sprintManagement.web.mvc.entities;

public enum MeetingType {
DailyScrum,SprintPlanning,SprintReview,SprintRetrospective;
}
