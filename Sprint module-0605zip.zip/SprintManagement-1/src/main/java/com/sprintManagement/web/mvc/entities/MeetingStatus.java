package com.sprintManagement.web.mvc.entities;

//Enum for Meeting Status
public enum MeetingStatus {
scheduled,completed,cancelled,rescheduled;
}
