package com.sprintManagement.web.mvc.exceptions;

public class MeetingStatusUpdateFailedException extends Exception {

	

	public MeetingStatusUpdateFailedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


}
