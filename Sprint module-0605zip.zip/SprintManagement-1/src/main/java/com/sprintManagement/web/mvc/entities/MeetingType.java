package com.sprintManagement.web.mvc.entities;

//Enum for Meeting Type
public enum MeetingType {
DailyScrum,SprintPlanning,SprintReview,SprintRetrospective;
}
