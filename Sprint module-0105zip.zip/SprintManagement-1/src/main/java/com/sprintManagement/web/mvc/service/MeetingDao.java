package com.sprintManagement.web.mvc.service;

import java.util.List;

import com.sprintManagement.web.mvc.entities.Meetings;
import com.sprintManagement.web.mvc.exceptions.MeetingStatusUpdateFailedException;

public interface MeetingDao {
	List<Meetings> getAllMeetings();
	Meetings scheduleNewMeeting(Meetings meeting);
	Meetings getMeetingById(Long id);
	Meetings rescheduleMeeting(Meetings meeting,Long id) throws MeetingStatusUpdateFailedException;
	String addNewMeeting(Meetings meeting)throws Exception;
}
