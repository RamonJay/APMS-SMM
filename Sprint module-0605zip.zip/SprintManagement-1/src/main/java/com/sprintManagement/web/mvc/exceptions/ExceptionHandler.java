package com.sprintManagement.web.mvc.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ExceptionHandler {
	
	@org.springframework.web.bind.annotation.ExceptionHandler(MeetingStatusUpdateFailedException.class)
	public ResponseEntity<String> meetingStatusUpdateFailedExceptionHandler(){
		return new ResponseEntity<String>("Completed meeting cannot be updated",HttpStatus.BAD_REQUEST);
	}

}
