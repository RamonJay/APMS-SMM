package com.sprintManagement.web.mvc.testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@SpringBootTest
class sprintTesting {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
