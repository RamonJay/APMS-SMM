package com.sprintManagement.web.mvc.entities;

public enum MeetingStatus {
scheduled,completed,cancelled,rescheduled;
}
