package com.sprintManagement.web.mvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprintManagement1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
